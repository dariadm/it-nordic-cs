using System;

class Program
{
	static void Main()
	{
		var test = "a\tb\nc";
		Console.WriteLine(test);
		// a  b
		// c
	}
}